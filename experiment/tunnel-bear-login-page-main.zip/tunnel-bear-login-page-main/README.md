# TunnelBear Login Page Replica in React

This is a simple recreation of the cute login page from TunnelBear, built using React. The goal of this project was to replicate the visual design and functionality of the login page with minimal lines of code.

![preview](./public/preview.gif)
